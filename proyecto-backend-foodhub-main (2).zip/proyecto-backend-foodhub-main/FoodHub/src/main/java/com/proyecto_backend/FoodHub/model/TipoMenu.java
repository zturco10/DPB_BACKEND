package com.proyecto_backend.FoodHub.model;

public enum TipoMenu {
    ECONOMICO, ESTUDIANTIL, EJECUTIVO, SALUDABLE
}
