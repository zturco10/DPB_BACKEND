package com.proyecto_backend.FoodHub.model;

public enum Rol {
    ADMIN,
    KIOSKERO,
    CLIENTE
}
